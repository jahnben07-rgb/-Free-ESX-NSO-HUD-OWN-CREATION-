ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(200)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        local ped = PlayerPedId()
        local data = ESX.GetPlayerData()

        SendNUIMessage({
            action = 'update',
            health = GetEntityHealth(ped) - 100,
            armor = GetPedArmour(ped),
            job = data.job and data.job.name or 'unemployed',
            jobLabel = data.job and data.job.label or 'Unemployed'
        })
    end
end)
