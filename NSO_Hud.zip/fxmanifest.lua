fx_version 'cerulean'
game 'gta5'

author 'Rainbowline'
description 'ESX Minimap HUD V2 (Clean + Job Icons)'
version '2.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

client_script 'client.lua'
