fx_version 'cerulean'
game 'gta5'

author 'New State Online Team'
description 'New State online Old Hud'
version '2.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

client_script 'client.lua'
