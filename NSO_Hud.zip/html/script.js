const jobIcons = {
    police: '🚓',
    ambulance: '🚑',
    mechanic: '🔧',
    unemployed: '💼'
};

window.addEventListener('message', function(e) {
    if (e.data.action === 'update') {
        document.getElementById('jobtext').innerText = e.data.jobLabel;
        document.getElementById('jobIcon').innerText =
            jobIcons[e.data.job] || '💼';
    }
});
